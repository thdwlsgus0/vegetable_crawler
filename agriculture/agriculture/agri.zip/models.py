# Create your models here.
from djongo import models
from django import forms
from django.contrib.auth.models import User
def min_length_3_validator(value):
    if len(value) < 3:
        raise forms.ValidationError('3글자 이상 입력해주세요')
class Signup(models.Model):
    ID = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    Email = models.CharField(max_length=100)
   
class Emoticon(models.Model):
    like = models.CharField(max_length=100)
    warm = models.CharField(max_length=100)
    sad = models.CharField(max_length=100)
    angry = models.CharField(max_length=100)
    want = models.CharField(max_length=100)
    class Meta:
        abstract = True
class Document(models.Model):
   description = models.CharField(max_length=255, blank=True)
   file =  models.FileField(upload_to = 'webapp/')
   uploaded_at = models.DateTimeField(auto_now_add=True)
class EmoticonForm(forms.ModelForm):
    class Meta:
        model = Emoticon
        fields = (
            'like','warm','sad','angry','want'
        )
class UploadFileModel(models.Model):
   title = models.TextField(default='')
   file = models.FileField(null=True)
class title(models.Model):
    media = models.CharField(max_length=200)
    main_title = models.CharField(max_length=200, null=True)
    datetime = models.CharField(max_length=200, null=True)
    main_body = models.CharField(max_length=12000, null=True)
    count = models.FloatField(max_length=200)
    class Meta:
        abstract = True
class titleForm(forms.ModelForm):
    class Meta:
        model = title
        fields = (
           'media', 'main_title', 'datetime', 'main_body', 'count'
        )
class blogtitle(models.Model):
      main_title = models.CharField(max_length=200)
      main_body = models.CharField(max_length=200)
      datetime = models.CharField(max_length=12000)
      class Meta:
        abstract = True
class blogForm(forms.ModelForm):
       class Meta:
           model = blogtitle
           fields = (
           'main_title','main_body','datetime'
           )
class daum_blog(models.Model):
    keyword = models.CharField(max_length=100)
    sub_body = models.EmbeddedModelField(
       model_container = title,
       model_form_class= titleForm
  )
    tag = models.CharField(max_length=100, null=True)
    comment = models.CharField(max_length=10000, null= True)
class KBS(models.Model):
    keyword = models.CharField(max_length=100)
    sub_body = models.EmbeddedModelField(
        model_container = title,
        model_form_class= titleForm
    )
class user_data(models.Model):
    ID = models.CharField(max_length=100)
    keyword = models.CharField(max_length=100)
    sub_body = models.EmbeddedModelField(
        model_container = title,
        model_form_class = titleForm
    )
class state1(models.Model):
    login_id = models.CharField(max_length=100)
    keyword = models.CharField(max_length=100)
    start_date = models.CharField(max_length=100)
    end_date = models.CharField(max_length=100)
    today_date = models.CharField(max_length=100)
    state = models.CharField(max_length=100, null=True)
    type_state = models.CharField(max_length=100, null=True)
class MBC(models.Model):
    keyword = models.CharField(max_length=200)
    sub_body = models.EmbeddedModelField(
        model_container = title,
        model_form_class = titleForm
    )

class SBS(models.Model):
    keyword = models.CharField(max_length=100)
    sub_body = models.EmbeddedModelField(
        model_container = title,
        model_form_class = titleForm
    )


class JTBC(models.Model):
    keyword = models.CharField(max_length=130)
    sub_body = models.EmbeddedModelField(
        model_container=title,
        model_form_class=titleForm
    )

class YTN(models.Model):
    keyword = models.CharField(max_length=130)
    sub_body = models.EmbeddedModelField(
        model_container=title,
        model_form_class=titleForm
    )

class dailyEconomy(models.Model):
    keyword = models.CharField(max_length=130)
    sub_body = models.EmbeddedModelField(
        model_container=title,
        model_form_class=titleForm
    )

class moneyToday(models.Model):
    keyword = models.CharField(max_length=130)
    sub_body= models.EmbeddedModelField(
        model_container=title,
        model_form_class=titleForm
    )

class eDaily(models.Model):
    keyword = models.CharField(max_length=130)
    sub_body = models.EmbeddedModelField(
        model_container=title,
        model_form_class=titleForm
    )

class seoulEconomy(models.Model):
    keyword = models.CharField(max_length=130)
    sub_body = models.EmbeddedModelField(
        model_container=title,
        model_form_class=titleForm
    )

class koreaEconomy(models.Model):
    keyword = models.CharField(max_length=130)
    sub_body = models.EmbeddedModelField(
        model_container=title,
        model_form_class=titleForm
    )

class naver(models.Model):
    keyword = models.CharField(max_length=130)
    sub_body = models.EmbeddedModelField(
        model_container = title,
        model_form_class=titleForm
    )
    main_url = models.CharField(max_length=130, null=True)

class daum(models.Model):
    keyword = models.CharField(max_length=130)
    sub_body = models.EmbeddedModelField(
        model_container = title,
        model_form_class=titleForm
    )

