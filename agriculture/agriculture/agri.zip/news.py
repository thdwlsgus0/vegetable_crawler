from bs4 import BeautifulSoup
import requests, threading
import time
from .models import title, state1, KBS,SBS,MBC,JTBC,YTN, dailyEconomy, moneyToday, eDaily, seoulEconomy, koreaEconomy,Emoticon
class news_crawler(threading.Thread):
    def __init__(self,keyword, sd, ed, ID,media,t,b,d,k,e,c,l,number):
      threading.Thread.__init__(self)
      self.keyword = keyword
      self.sd = sd
      self.ed = ed
      self.ID = ID
      self.t = t
      self.b = b
      self.d = d
      self.k = k
      self.e = e
      self.c = c
      self.l = l
      self.media=media
      self.number = number
    def get_bs_obj(self, keyword, sd, ed, page): # beautifulsoup 객체 얻음
         url = "https://search.daum.net/search?nil_suggest=btn&w=news&DA=STC&cluster=y&q="+keyword+"&p="+page+"&sd="+sd+"000000&ed="+ed+"235959&period=u"
         result = requests.get(url)
         bs_obj = BeautifulSoup(result.content, "html.parser")
         return bs_obj
    def get_data_date(self, keyword, sd, ed, page): #날짜 확인하기
        bs_obj = self.get_bs_obj(keyword, sd, ed, page) 
        total_num = bs_obj.find("span",{"class":"txt_info"})
        total_num = self.get_total_num(total_num)
        return total_num
    def get_total_num(self,total_num): # 건수 예외처리하기 
         total_text = total_num.text
         split = total_text.split()
         length = len(split)
         if length == 4:
           text = split[3].replace(",","")
           text = text.replace("건","")
         else:
           text = split[2].replace(",","")
           text = text.replace("건","")
         text = int(text)
         return text
    def get_bs_incontent(self, url):
         result = requests.get(url)
         bs_obj = BeautifulSoup(result.content, "html.parser")
         return bs_obj
    def run(self):
        datevalue = self.get_data_date(self.keyword, self.sd, self.ed, "1")         
        print(datevalue)
        datevalue = int(datevalue/10)
        for i in range(0,datevalue):
            page = str(i)
            bs_obj = self.get_bs_obj(self.keyword, self.sd, self.ed, page)
            news_lists = bs_obj.findAll("div",{"class":"wrap_cont"})
            for li in news_lists:
                 time.sleep(2)
                 span_text = li.find("span",{"class":"f_nb date"}).text
                 span_split = span_text.split()
                 len_span = len(span_split)
                 if len_span == 3:
                   continue 
                 elif len_span == 5:
                       a_url = li.find("a",{"class":"f_nb"})
                       new_a_url = a_url['href']  
                       new_bs_obj = self.get_bs_incontent(new_a_url)
                       Title = new_bs_obj.find("h3",{"class":"tit_view"}).text
                       body = new_bs_obj.find("div",{"id":"mArticle"}).text
                       times = new_bs_obj.find("span",{"class":"txt_info"}).text 
                       print(self.k)
                       if self.k != "k":
                          self.keyword = ""
                       if self.b != "b":
                          body = ""
                       if self.d != "d":
                          times = ""
                       if self.t !="t":
                          Title = ""
                       contents = title(main_title = Title, main_body =body, datetime = times, media="서울경제", count=1)
                       print(Title)
                       print(span_split[2])
                       print(self.media['daily'])
                       if span_split[2] == "KBS" and self.media['kbs']==True:
                                 kbs = KBS()
                                 kbs.keyword = self.keyword
                                 kbs.sub_body = contents
                                 kbs.save()
                       elif span_split[2] == "MBC" and self.media['mbc'] ==True:
                                 mbc = MBC()
                                 mbc.keyword = self.keyword
                                 mbc.sub_body = contents
                                 mbc.save()
                       elif span_split[2] == "SBS" and self.media['sbs'] ==True:
                                 sbs = SBS()
                                 sbs.keyword = self.keyword
                                 sbs.sub_body = contents
                                 sbs.save()
                       elif span_split[2] == "JTBC" and self.media['jtbc']==True:
                                 jtbc = JTBC()
                                 jtbc.keyword = self.keyword
                                 jtbc.sub_body = contents
                                 jtbc.save()
                       elif span_split[2] == "YTN" and self.media['ytn']==True:
                                 ytn = YTN() 
                                 ytn.keyword = self.keyword
                                 ytn.sub_body = contents
                                 ytn.save()
                       elif span_split[2] == "매일경제" and self.media['daily']==True:
                                 dailyEco = dailyEconomy()
                                 dailyEco.keyword = self.keyword
                                 dailyEco.sub_body = contents
                                 dailyEco.save()
                       elif span_split[2] == "머니투데이" and self.media['money']==True:
                                 money = moneyToday()
                                 money.keyword = self.keyword
                                 money.sub_body = contents
                                 money.save()
                       elif span_split[2] == "이데일리" and self.media['eDaily']==True: 
                                 edaily = eDaily()
                                 edaily.keyword = self.keyword
                                 edaily.sub_body = contents
                                 edaily.save()
                       elif span_split[2] == "서울경제" and self.media['seoul']==True:    
                                 seoul = seoulEconomy()
                       	         seoul.keyword = self.keyword
                                 seoul.sub_body = contents
                                 seoul.save()
                       elif span_split[2] == "한국경제" and self.media['korea']==True:
                                 korea = koreaEconomy()
                                 korea.keyword = self.keyword
                                 korea.sub_body = contents
                                 korea.save()
        name = state1.objects.filter(id=self.number)
        for name_value in name:
           name_value.state= 2
           name_value.save()
        print("끝")