from django.apps import AppConfig


class VegetableConfig(AppConfig):
    name = 'vegetable'
