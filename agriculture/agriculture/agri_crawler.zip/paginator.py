from django.shortcuts import render

from django.core.paginator import Paginator

def page(request):
   
