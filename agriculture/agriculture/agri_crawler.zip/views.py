

# Create your views here.
from django.shortcuts import render
from bs4 import BeautifulSoup
from django.http import JsonResponse
from django.http import HttpResponse
from operator import eq
from django.db.models import Q
from .models import state1,title,KBS,SBS,MBC,JTBC,YTN,dailyEconomy,moneyToday,eDaily,seoulEconomy,koreaEconomy,naver,Emoticon
from .models import Signup
from random import *
import time, threading
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from django.shortcuts import  redirect
from .forms import UserForm, LoginForm
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate
from django.template import RequestContext
from django.views import View
from django.utils.encoding import python_2_unicode_compatible
from .signup import *
#from .classfier import *
from .blogview import *
from .daum_blog import *
from .naver_blog import *
from .news import *
import numpy as np
import pandas as pd
import datetime
import os
import sys
import json
import math
import requests
import django
import re
import csv,codecs
import uuid
#import matplotlib.pyplot as plt
#import matplotlib
from time import sleep
from .forms import DocumentForm
from importlib import import_module
from .models import Document
from django.conf import settings
#from konlpy.tag import *
#from konlpy.utils import pprint
from multiprocessing import Pool
from datetime import datetime
from django.core.paginator import Paginator
from django.template import loader
django.setup()
global BC8
def index(request):
    return render(request, 'agri_crawler/index.html',{})
def kmeans(request):
    return render(request, 'agri_crawler/kmeans.html',{})
def loading(request):
    return render(request, 'agri_crawler/loading.html',{})
def login(request):
    return render(request, 'agri_crawler/login.html',{})
def signup(request):
    return render(request, 'agri_crawler/signup.html',{})
def practice(request):
    return render(request, 'agri_crawler/practice.html',{})
def logout(request):
    request.session.flush()
    return render(request, 'agri_crawler/login.html',{})
def positive(request):
    keyword = request.POST.get('keyword')
    name = daum_blog.objects.filter(keyword= keyword)
    f = open('output.csv', 'w', encoding='utf-8')
    wr = csv.writer(f, delimiter=' ', quotechar=' ')
    wr.writerow("본문내용")
    for i in name:
       wr.writerow(str(i.sub_body.main_body))
    f.close()
    return render(request, 'agri_crawler/positive.html',{})
def bloglist(request): # 개인 블로그 수집 현황 파악
       name = request.POST.get('User')
       wating = state1.objects.filter(type_state=3, login_id=name)
       return render(request, 'agri_crawler/waiting.html',{'waiting':wating})
def newslist(request): # 개인 뉴스 수집 현황 파악
       name = request.POST.get('User')
       wating = state1.objects.filter(type_state=2, login_id=name)
       return render(request, 'agri_crawler/waiting1.html',{'waiting':wating})
def alllist(request):
       wating = state1.objects.all()
       return render(request, 'agri_crawler/waiting2.html',{'waiting':wating})
from django.core.mail import send_mail
def sendmail(request):
     name = request.POST.get('name')
     email = request.POST.get('email')
     message = request.POST.get('message') 
     send_mail(name, message, email, ['thdtdmgus0@gmail.com'], fail_silently=False)
     return render(request, 'agri_crawler/index.html')
def waiting(request): # 뉴스 
    text = request.POST.get('text1')
    start_date = request.POST.get('start_date1')
    end_date = request.POST.get('end_date1')
    KBS = request.POST.get('KBS')
    MBC = request.POST.get('MBC')
    SBS = request.POST.get('SBS')
    JTBC = request.POST.get('JTBC')
    YTN = request.POST.get('YTN')
    Daily = request.POST.get('daily')
    Money = request.POST.get('money')
    eDaily = request.POST.get('eDaily')
    seoul = request.POST.get('seoul')
    korea = request.POST.get('korea')
    title = request.POST.get('t')
    date = request.POST.get('d')
    keyword = request.POST.get('k')
    body =  request.POST.get('b')
    emoticon = request.POST.get('e')
    comment = request.POST.get('c')
    recommend = request.POST.get('r')
    ID = request.POST.get('id')
    now = datetime.now() 
    today_date = str(now.year)+"."+str(now.month)+"."+str(now.day)
    State1 = state1()
    State1.keyword = text
    State1.start_date = start_date
    State1.end_date = end_date
    State1.today_date = today_date
    State1.login_id=ID
    State1.state = 0
    State1.type_state=2
    State1.save()
    condition = State1.state
    query = state1.objects.filter(login_id= ID)
    waiting = query
    #page_row_count = 5 
    #page_display_count = 5 # 화면에 보이는 display 개수   
    Users = state1.objects.filter(login_id=ID) 
    #paginator = Paginator(User, page_row_count)
    #pageNum = request.GET.get('pageNum')
    #totalPageCount = paginator.num_pages # 전체 페이지 갯수
    #try:
      # member_list = paginator.page(pageNum)
    #except PageNotAnInteger:
     #  member_list = paginator.page(1)
     #  pageNum = 1
    #except EmptyPage:
     #  member_list = paginator.page(paginator.num_pages)
     #  pageNum = paginator.num_pages
    
    #pageNum = int(pageNum)
    
    #startPageNum = 1+((pageNum-1)/page_display_count)*page_display_count
    #endPageNum = startPageNum + page_display_count-1
    #if totalPageCount < endPageNum:
     #  endPageNum = totalPageCount
    
    #bottomPages = range(startPageNum, endPageNum+1)
    
    data={'start_date': start_date, 'end_date':end_date, 'title':title, 'date':date, 'keyword':text, 'body':body, 'emoticon':emoticon, 'comment':comment, 'recommend':recommend}
    return render(
              request,
              'agri_crawler/waiting1.html',
              {  
                'waiting':waiting,
                'data':data,
                'Users':Users
               }
          )
def wating(request): #블로그
    text1 = request.POST.get('text1')#키워드
    start_date = request.POST.get('start_date1') #시작기간
    end_date = request.POST.get('end_date1') #종료기간
    naver_blog = request.POST.get('naver')
    daum_blog = request.POST.get('daum')
    title = request.POST.get('t')
    date = request.POST.get('d')
    keyword = request.POST.get('k')
    body = request.POST.get('b')
    emoticon = request.POST.get('e')
    comment  = request.POST.get('c')
    recommend = request.POST.get('r')
    ID = request.POST.get('id')
    now = datetime.now()
    today_date = str(now.year)+"."+str(now.month)+"."+str(now.day)
    State1 = state1()
    State1.keyword = text1
    State1.start_date = start_date
    State1.end_date = end_date
    State1.today_date = today_date
    State1.login_id=ID
    State1.state = 0
    State1.type_state=3
    State1.save()
    query = state1.objects.filter(login_id = ID) 
    waiting = query
    data = {'daum_blog':daum_blog,'naver_blog': naver_blog,'text1': text1,'start_date': start_date,'end_date': end_date, 'title':title,'date': date, 'keyword':keyword,'body': body, 'emoticon':emoticon, 'comment':comment,'recommend': recommend}
    return render(request, 'agri_crawler/waiting.html',{'waiting':waiting, 'data':data})
    #def negative(request): # 긍/부정 판단하게 하는 부분
    #positive=0
    #negative=0
    #neutral=0
    #f = open('result.txt', 'r', encoding='utf8')
    #lines = f.readlines()
    #for i,line in enumerate(lines):
    #   if i==0:
    #     kw = line
    #     continue
    #   elif '동영상' in line:
    #     continue
    #   elif 'function' in line:
    #     continue
    #   elif '//' in line:
    #     continue
    #   elif len(line.split())==0:
    #    continue
    #   sort = classfier()
    #   if sort.naive_classfier(str(line)) == 1:
    #      positive = positive+1
    #   elif sort.naive_classfier(str(line))==0:
    #      negative = negative+1
    #   elif sort.naive_classfier(str(line))==-1:
    #      neutral = neutral+1
    #f.close()
    #data = {'positive':positive, 'negative':negative, 'kw' :kw, 'neutral':neutral}
    #return render(request, 'vegetable/googlechartnegative.html',{'data':data})
def idcheck(request):
    id = request.POST.get('id',None)
    data ={
     'is_taken':Signup.objects.filter(ID=id).exists()
    }
    return JsonResponse(data)
#def identify(request):
#    cits = Signup.objects.all().filter(ID="송진현")
#    return render(request, 'vegetable/identify.html',{})
def d3(request):
    request_getdata = request.POST.get('value','None')
    data = state1.objects.filter(id=request_getdata) 
    for dt in data:
      dt.state = "1" 
      dt.save()   
    return render(request,'agri_crawler/d3.html')
def auth_login(request):
    id = request.POST.get('username',None)
    password = request.POST.get('password',None)
    #is_id = Signup.objects.filter(ID=id).exists()
    #is_password = Signup.objects.filter(password=password).exists()
    is_id = Signup.objects.filter(ID =id).exists()
    is_password = Signup.objects.filter(password = password).exists()
    data= {'username':is_id, 'password':is_password}
    if is_id == True and is_password == True:
       request.session['username'] = request.POST['username']
       return redirect('index')
    else:
       return redirect('login')
def complete(request):
     sign = signUp()
     ID = request.POST.get('ID')
     password = request.POST.get('Password')
     email = request.POST.get('email')
     sign.post(ID, password, email)
     return render(request, 'agri_crawler/login.html',{})
class url_collector:
   def __init__(self):
      self.req_header = {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36'}
      
      self.url = "https://search.naver.com/search.naver?ie=utf8&where=news"
   def add_property(self, Str, point_start_date, point_end_date, start):
       self.param = {
                'query': Str.encode('utf-8').decode('utf-8'),
                    'sm':'tab_pge',
                    'sort': '2',
                    'photo':'0',
                    'field':'0',
                    'pd':'3',
                    'ds': point_start_date,
                    'de': point_end_date,
                    'nso': 'so:r,p:',
                    'start': str(10*start+1)
            }
       return self.param
def login_session():
    with requests.Session() as s:
        req = s.get("https://nid.naver.com/nidlogin.login")
        html = req.text
        header = req.headers
        status = req.status_code
        is_ok = req.ok
def processing():
    start_time  = time.time()
    pool = Pool(precesses=32)
    pool.map(tests)
    print(time.time()-start_time)
def task(request):
    return render(request, 'agri_crawler/waiting1.html')
def state_save(Str, start_date, end_date, ID):
    now = datetime.now()
    today_date = str(now.year) + "." + str(now.month) + "." + str(now.day)
    State1 = state1()
    State1.keyword = Str
    State1.start_date = start_date
    State1.end_date = end_date
    State1.today_date = today_date
    State1.login_id = ID
    State1.state = 0
    State1.type_state = 2
    State1.save()
def tests(request):
    if request.method =='POST':
          Str = str(request.POST.get('text1'))  
          start_date = request.POST.get('start_date1')
          end_date = request.POST.get('end_date1')
          start = start_date.replace("-","")
          end = end_date.replace("-","")
          title = request.POST.get('t')
          main_body = request.POST.get('b')
          date = request.POST.get('d')
          keyword = request.POST.get('k')
          emoticon = request.POST.get('e')
          comment = request.POST.get('c')
          recommend = request.POST.get('l') 
          ID = request.POST.get('id')
          media={}
          if request.POST.get('KBS') == "KBS":     
             media['kbs']=True
          if request.POST.get('MBC') == "MBC":
             media['mbc']=True
          if request.POST.get('SBS') == "SBS":
             media['sbs']=True
          if request.POST.get('JTBC') == "JTBC":
             media['jtbc']=True
          if request.POST.get('YTN') == "YTN":
             media['ytn']=True
          if request.POST.get('daily') == "daily":
             media['daily']=True
          if request.POST.get('money') == "money":
             media['money']=True
          if request.POST.get('eDaily') == "eDaily":
             media['eDaily']=True
          if request.POST.get('seoul') == "seoul":
             media['seoul']=True
          if request.POST.get('korea') == "korea":
             media['korea']=True
          state_save(Str, start_date, end_date, ID)
          query = state1.objects.filter(login_id=ID)
          waiting = query
          name = state1.objects.filter(login_id=ID).order_by('-id').first()
          number = name.id
          news_collector = news_crawler(Str, start, end, ID,media, title, main_body, date, keyword, emoticon, comment, recommend,number)
          news_collector.start()
          data = {'text1': Str,'start_date': start,'end_date': end, 'title':title,'date': date, 'keyword':Str,'body': main_body}
    return render(request,'agri_crawler/waiting1.html',{'waiting':waiting,'data':data})
def product(request):
    return render(request, 'agri_crawler/product_0818.html',{})
def navertest(request):
    global bkw
    if request.method == 'POST': # 만약 POST 방식으로 전달이 되었으면
        if request.POST.get('naver'):
          Str = str(request.POST.get('text1'))
          start_date =  request.POST.get('start_date1')
          end_date = request.POST.get('end_date1')
          start = start_date.replace("-","")
          end = end_date.replace("-","")
          title = request.POST.get('t')
          main_body = request.POST.get('b')
          date = request.POST.get('d')
          keyword = request.POST.get('k')
          url = request.POST.get('url')
          ID = request.POST.get('id')
          state_save(Str, start_date, end_date, ID)
          query = state1.objects.filter(login_id=ID)
          number = state1.objects.filter(login_id=ID).order_by('-id').first()
          naver_collector = naver_crawler(Str,start,end,title,main_body,date,keyword,url,ID,number)
          naver_collector.start()
          data = {'text1': Str, 'start_date': start, 'end_date': end, 'title': title, 'date': date, 'keyword': Str,
                  'body': main_body}
          return render(request, 'agri_crawler/waiting.html',{'waiting':query, 'data':data})
        if request.POST.get('daum'):
          Str = str(request.POST.get('text1')) # 검색어
          bkw = Str
          start_date = request.POST.get('start_date1') # 시작시간
          end_date = request.POST.get('end_date1') # 도착시간
          start = start_date.replace("-","") # -을 제거     
          end  = end_date.replace("-","")
          title = request.POST.get('t')
          main_body = request.POST.get('b')  
          date = request.POST.get('d')   
          key = request.POST.get('k')
          tag = request.POST.get('tag')
          comment = request.POST.get('comment')
          ID = request.POST.get('id')
          state_save(Str, start_date, end_date, ID)
          query = state1.objects.filter(login_id=ID)
          name = state1.objects.filter(login_id=ID).order_by('-id').first()
          print(name.id)
          waiting = query
          daum_collector = daum_crawler(bkw,start,end,ID,title,main_body,datetime,key,tag,comment)
          daum_collector.start()
          data = {'text1': Str,'start_date': start,'end_date': end, 'title':title,'date': date, 'keyword':Str,'body': main_body}
          return render(request, 'agri_crawler/waiting.html', {'waiting':waiting, 'data':data})
